JAYDEN'S DSP CORE RESIT REVISION HUB

1. Open index.html to preview the site locally.
2. To publish free with GitHub Pages:
   - Create a new PUBLIC repository.
   - Upload index.html, style.css, app.js and manifest.webmanifest to the repository root.
   - In the repository, open Settings > Pages.
   - Under Build and deployment, choose Deploy from a branch.
   - Choose main and /(root), then Save.
   - GitHub will provide the public site address after deployment.

No database is used. Flashcard progress is stored locally in the browser/device.
Do not put private personal information into the public repository/site.
